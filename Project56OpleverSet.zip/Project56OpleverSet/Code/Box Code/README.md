# App code
In deze map bevind zich alle code voor op de ESP32. Ook is er een kopie van het elektrisch schema is toegevoegd voor het gemak.

## changelog
| Wie | Wijzegingen| Wanneer | 
|-----|--------|--|
|Ivo Bruinsma| Aanmaken bestand |21-02-2025|
|Ivo Bruinsma| Correctie spelfout | 23-02-2025 |
