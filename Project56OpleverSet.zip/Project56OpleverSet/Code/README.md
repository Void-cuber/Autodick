# Code
In deze map bevind zich alle code die nodig is voor dit project. Dit is opgedeeld in twee verschillende mapjes:
## - **App code**
Onder het mapje [App Code](https://github.com/ammielb/AutoDick3/tree/master/Project56OpleverSet/Code/App%20Code) kan je alle benodigde files voor het builden van de app. Hier staat ook een README met alle benodigde stappen.

## -**Box code**
Onder het mapje [Box Code](https://github.com/ammielb/AutoDick3/tree/master/Project56OpleverSet/Code/Box%20Code) staat de benodigde code voor een ESP32. Ook bevind zich hier een extra kopie van het elektrisch schema voor het maken van de complete box.


## changelog
| Wie | Wijzegingen| Wanneer | 
|-----|--------|--|
|Ivo Bruinsma| Aanmaken bestand |21-02-2025|